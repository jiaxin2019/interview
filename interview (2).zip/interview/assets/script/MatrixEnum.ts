export interface WeigeItem{
    color:string,
    weight:number
}